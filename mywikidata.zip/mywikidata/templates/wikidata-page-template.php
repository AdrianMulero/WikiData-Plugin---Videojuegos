<?php
/**
 * Template Name: Wikidata Page
 *
 */
?>

<?php get_header() ?>

<div class="wrap">

		<fieldset>
            <legend>Buscador de videojuegos</legend>
			<p>Consulta videojuegos por diferentes categorías</p>
			<form method="post" name="front_end" action="" >
				<p>
				<label for="numresults">Categoria:</label><br>
				<select name="movement">
				  <option value="Q846224">Juegos de Lucha</option>
				  <option value="Q860750">Juegos de carreras</option>
				  <option value="Q828322">Juegos de plataformas</option>
				  <option value="Q7888616">Juegos de fiesta</option>
				  <option value="Q343568">Juegos de aventura</option>
				  <option value="Q868217">Juegos de deporte</option>
				  <option value="Q54767">Juegos de puzzles</option>
				</select>
				</p>
				
				<p>
				<label for="numresults">Número resultados:</label><br>
				<select name="numresults">
				  <option value="10">10</option>
				  <option value="20">20</option>
				  <option value="50">50</option>
				  <option value="100">100</option>
				  <option value="all">Todos</option>
				</select>
				</p>
				<input type="hidden" name="new_search" value="1"/>
				<button type="submit">Buscar</button>
			</form>
		</fieldset>
		
			<?php
			if(isset($_POST['new_search']) == '1') {
				$movement = $_POST['movement'];
				
				if(isset($numresults))
					$numresults = $_POST['numresults'];
				else
					$numresults = 10;
				
				movement_wikidata_call($movement, $numresults);
			}
			?>
            
</div><!-- .wrap -->


<?php get_footer() ?>